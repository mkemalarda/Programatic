import UIKit

//var membersList : [String] = ["Ahmet","Mehmet","Fatma","Zeynep","Oğuzhan"]

class neonAcademyMember {
    var fullName : String = ""
    var title : String = ""
    var horoscope : String = ""
    var memberLevel : String = ""
    var homeTown : String = ""
    var age : Int = 0
    
}


class contactInformation : neonAcademyMember {
    var phoneNumber : Int = 0
    var email : String = ""
    
}

let member1 = neonAcademyMember()
member1.fullName = "Mustafa Kemal ARDA"
member1.title = "iOS Developer"
member1.horoscope = "Fish"
member1.memberLevel = "A1"
member1.homeTown = "İzmir"
member1.age = 27











