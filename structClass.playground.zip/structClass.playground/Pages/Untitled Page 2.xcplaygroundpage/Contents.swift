import UIKit

class Members {
    var fullName : String
    var title : String
    var horoscope : String
    var memberLevel : String
    var homeTown : String
    var age : Int
    var contactInformation : ContactInformation
    var mentorLevel : String?
    
    init(fullName: String, title: String, horoscope: String, memberLevel: String, homeTown: String, age: Int, contactInformation : ContactInformation, mentorLevel : String? = nil) {
        self.fullName = fullName
        self.title = title
        self.horoscope = horoscope
        self.memberLevel = memberLevel
        self.homeTown = homeTown
        self.age = age
        self.contactInformation = contactInformation
    }
    
}

struct ContactInformation {
    var phoneNumber : Int
    var email: String

    }

/*
private func addPerson(_ neonAcademyMember: Members) {
  myArray.append(neonAcademyMember)
}
*/


let m1contactInformation = ContactInformation(phoneNumber: 123, email: "aa@gmail.com")
let m1 = Members(fullName: "mustafa", title: "ios dev", horoscope: "fish", memberLevel: "A1", homeTown: "Istanbul", age: 27, contactInformation: m1contactInformation)


let m2contactInformation = ContactInformation(phoneNumber: 333, email: "bb@gmail.com")
let m2 = Members(fullName: "emre", title: "designer", horoscope: "cancer", memberLevel: "A2", homeTown: "Istanbul", age: 23, contactInformation: m2contactInformation)

let m3contactInformation = ContactInformation(phoneNumber: 444, email: "cc@gmail.com")
let m3 = Members(fullName: "okan", title: "tester", horoscope: "twins", memberLevel: "A2", homeTown: "Istanbul", age: 32, contactInformation: m3contactInformation )

let m4contactInformation = ContactInformation(phoneNumber: 555, email: "dd@gmail.com")
let m4 = Members(fullName: "zeynep", title: "android dev", horoscope: "scales", memberLevel: "A1", homeTown: "Aaaaaa", age: 24, contactInformation: m4contactInformation)

let m5contactInformation = ContactInformation(phoneNumber: 666, email: "ff@gmail.com")
let m5 = Members(fullName: "hasan", title: "ios dev", horoscope: "fish", memberLevel: "A3", homeTown: "Istanbul", age: 29, contactInformation: m5contactInformation)

let m6contactInformation = ContactInformation(phoneNumber: 777, email: "gg@gmail.com")
let m6 = Members(fullName: "mehmet", title: "designer", horoscope: "cancer", memberLevel: "B1", homeTown: "Erzurum", age: 30, contactInformation: m6contactInformation)

let m7contactInformation = ContactInformation(phoneNumber: 888, email: "hh@gmail.com")
let m7 = Members(fullName: "hüseyin", title: "ios dev", horoscope: "goat", memberLevel: "B2", homeTown: "İzmir", age: 35, contactInformation: m7contactInformation)


var myArray = [Members]()
myArray.append(m1)
myArray.append(m2)
myArray.append(m3)
myArray.append(m4)
myArray.append(m5)
myArray.append(m6)
myArray.append(m7)


print(m1.fullName)
print(m1.title)
print(m1.horoscope)
print(m1.memberLevel)
print(m1.homeTown)
print(m1.age)
print(m1.contactInformation.phoneNumber)
print(m1.contactInformation.email)


print(m2.fullName)
print(m2.title)
print(m2.horoscope)
print(m2.memberLevel)
print(m2.homeTown)
print(m2.age)
print(m2.contactInformation.phoneNumber)
print(m2.contactInformation.email)


for i in myArray {
    print(i.fullName)
}



print(myArray.count)

//MARK: - Delete the 3rd member.
myArray.remove(at: 2)

//MARK: - Rank the members according to their age from largest to smallest.
for a in myArray {
    print(a.age)
}
myArray = myArray.sorted { $0.age > $1.age }.map({ $0 })

print("*************")

for a in myArray {
    print(a.age)
}

print("*************")

//MARK: - Sort the members according to their names (Z-A).
for b in myArray {
    print(b.fullName)
}

print("*************")

myArray = myArray.sorted(by: { $0.fullName > $1.fullName }) .map({$0})

for b in myArray {
    print(b.fullName)
}

print("*************")

//MARK: - Filter the members of the Academy who are older than 24 and transfer them to a new array. Print the names of the members in this array.

var myArrayAge = myArray.filter({$0.age > 24 }) .map({$0})

for a in myArrayAge {
    print(a.fullName)
}

print("*************")

//MARK: - Print the total number of iOS Developers.

for x in myArray {
    print(x.title)
}


var myArrayTitle = myArray.filter({$0.title == "ios dev" }) .map({$0})

print("*************")

for x in myArrayTitle {
    print(x.title)
}

print(myArrayTitle.count)

//MARK: - Find which index you come across in the array and print it.
print("*************")

for y in myArray {
    print(y.fullName)
}

myArray = myArray.sorted(by: { $0.fullName > $1.fullName }) .map({$0})
print("*************")

for y in myArray {
    print(y.fullName)
}


//MARK: - Add a new member to the array, who is a mentor of the academy and has a special property "mentorLevel" indicating their level of experience. Print out the full names of all members after adding the new member.

print("*************")

let m8contactInformation = ContactInformation(phoneNumber: 999, email: "kk@gmail.com")
let m8 = Members(fullName: "ayşe", title: "ios dev", horoscope: "fish", memberLevel: "C2", homeTown: "İzmir", age: 40, contactInformation: m8contactInformation)

myArray.append(m8)


for p in myArray {
    print(p.fullName)
}


//MARK: - Remove all members who have a specific memberLevel, for example, "A1", and print out the remaining members' full names.
for t in myArray {
    print(t.fullName)
}
myArray.removeAll { $0.memberLevel == "A1" }
print("*************11")

for t in myArray {
    print(t.fullName)
}

//MARK: - Find the member with the highest age and print out their full name and age.

print("*************12")

var highestAge = myArray.sorted(by: { $0.age > $1.age }) .map({$0}).first!

print("\(highestAge.fullName) - \( highestAge.age)")


//MARK: - Find the member with the longest name and print out their full name and the length of their name.

print("*************13")

var longestName = myArray.sorted { $0.fullName.count > $1.fullName.count}.first!

print("\(longestName.fullName.count) - \(longestName.fullName)")

//MARK: - Find all members who have the same horoscope sign and group them together in a new array. Print out the full names of members in this new array.
print("*************136")

var sameHoroscope = Dictionary(grouping: myArray, by: {$0.horoscope})
    .filter { $0.value.count > 1 }
    .flatMap{$0.value}
    .map { $0.fullName }
print(sameHoroscope)


//MARK: - Find the most common hometown among the members and print out the name of the town.
print("*************154")

var sameHomeTown = Dictionary(grouping: myArray, by: {$0.homeTown})
    .filter {$0.value.count > 1}
    .flatMap {$0.value}
    .map{$0.homeTown}
print(sameHomeTown)

print("*************14")

var mostHomeTown = myArray.filter {$0.homeTown == $0.homeTown}.map({$0.homeTown})

for e in mostHomeTown {
    print("\(e)")
}


//MARK: - Find the average age of all members and print out the result.

var averageAge = (myArray.reduce(0, {$0 + $1.age}) / myArray.count)

print(averageAge)

print("*************199")

//MARK: - Create a new array that contains only the contact information of the members, and print out the email addresses of all members in this new array.

var sameInformation = myArray.map {$0.contactInformation.email}
print(sameInformation)




//MARK: - Sort the members according to their memberLevel (highest to lowest) and print out their full names.
print("*************15")

myArray = myArray.sorted(by: {$0.memberLevel > $1.memberLevel}).map({$0})

for r in myArray {
    print(r.fullName)
}


//MARK: - Find all members who have the same title and create a new array of their contact information, then print out the phone numbers of all members in this new array.


print("*************16")

print(myArray.filter({$0.title == $0.title}) .map({$0.contactInformation.phoneNumber}))

