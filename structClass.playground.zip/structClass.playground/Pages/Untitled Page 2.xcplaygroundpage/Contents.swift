import UIKit

class Members {
    var fullName : String
    var title : String
    var horoscope : String
    var memberLevel : String
    var homeTown : String
    var age : Int
    var contactInformation : contactInformation
    
    init(fullName: String, title: String, horoscope: String, memberLevel: String, homeTown: String, age: Int, contactInformation : contactInformation) {
        self.fullName = fullName
        self.title = title
        self.horoscope = horoscope
        self.memberLevel = memberLevel
        self.homeTown = homeTown
        self.age = age
        self.contactInformation = contactInformation
    }
    
}

struct contactInformation {
    var phoneNumber : Int
    var email: String

    }

let m1contactInformation = contactInformation(phoneNumber: 123, email: "aa@gmail.com")
let m1 = Members(fullName: "mustafa", title: "ios dev", horoscope: "fish", memberLevel: "A1", homeTown: "İzmir", age: 27, contactInformation: m1contactInformation)


let m2contactInformation = contactInformation(phoneNumber: 333, email: "bb@gmail.com")
let m2 = Members(fullName: "emre", title: "designer", horoscope: "cancer", memberLevel: "A2", homeTown: "Istanbul", age: 23, contactInformation: m2contactInformation)

let m3contactInformation = contactInformation(phoneNumber: 444, email: "cc@gmail.com")
let m3 = Members(fullName: "okan", title: "tester", horoscope: "twins", memberLevel: "A2", homeTown: "Ankara", age: 32, contactInformation: m3contactInformation )

let m4contactInformation = contactInformation(phoneNumber: 555, email: "dd@gmail.com")
let m4 = Members(fullName: "zeynep", title: "android dev", horoscope: "scales", memberLevel: "A1", homeTown: "Istanbul", age: 24, contactInformation: m4contactInformation)

print(m1.fullName)
print(m1.title)
print(m1.horoscope)
print(m1.memberLevel)
print(m1.homeTown)
print(m1.age)
print(m1.contactInformation.phoneNumber)
print(m1.contactInformation.email)


print(m2.fullName)
print(m2.title)
print(m2.horoscope)
print(m2.memberLevel)
print(m2.homeTown)
print(m2.age)
print(m2.contactInformation.phoneNumber)
print(m2.contactInformation.email)


